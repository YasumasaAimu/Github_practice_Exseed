// 必要な場合、インタラクティブな機能をここに追加
document.addEventListener("DOMContentLoaded", () => {
    console.log("ページが読み込まれました");
});